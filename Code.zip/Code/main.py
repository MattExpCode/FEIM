import ast
import argparse
import sys
import math
import networkx as nx
import random
import time
import copy
import graphProcessor
import sys
import numpy as np
#import Drawing
import EventInfluence
import os
from pathlib import Path
from random import sample
import time
random.seed(0)

def parse_args():
    parser = argparse.ArgumentParser(description="profit divergence minimization")
    parser.add_argument('--data_path_prefix', type=str, default='../Flood/')
    parser.add_argument('--data_path_suffix', type=str, default='.txt')
    parser.add_argument('--graph', type=str, default='/DiG_Tokens')
    parser.add_argument('--subgraph', type=str, default='/Reachable_Range/rr{}')
    parser.add_argument('--SE', type=str, default='/Event_Tokens')
    parser.add_argument('--thre', type=int, default='80',help='the percentage of eliminated reachability')
    parser.add_argument('--t', type=int, default='10',help='the number of seed users')
    parser.add_argument('--l', type=int, default='5',help='message limit')
    parser.add_argument('--interval', type=int, default='40',help='interval for reachable_range_search')
    parser.add_argument('--algo', type=str, default='FES')
    parser.add_argument('--EQuake_episodes', type=int, default='1059')
    parser.add_argument('--Flood_episodes', type=int, default='511')
    return parser.parse_args()


def diffusion(args, G, Event_tokens, episode, episode_start, last_episode):
    G, targets, rr = graphProcessor.loadGraph(args, G, Event_tokens, episode, episode_start, last_episode)
    bene, msg, inf, msg_gap, node_num = EventInfluence.FES(args, rr, targets)
    output = "epi " + str(episode) + " bene " + str(bene/1000) + " msg " + str(bene/msg) + " inf " + str(inf/1000) + " msg_gap " + str(msg_gap)
    print(output)
    return G, bene, msg, inf, msg_gap, node_num

def main(args):
    print(args.data_path_prefix)
    print(args.algo)
    print("l{} t{}".format(args.l, args.t))
    G = nx.DiGraph()
    episode_start = args.l - 1
    episode_end = args.Flood_episodes

    with open(args.data_path_prefix + args.graph + args.data_path_suffix, 'r', encoding = 'utf-8') as file:
        for line in file:
            edge, tokens, time = line.strip().split('\t')
            edge = ast.literal_eval(edge)
            sender = edge[0]
            receiver = edge[1]
            G.add_edge(sender, receiver)
            G.edges[edge]['feat'] = ast.literal_eval(tokens)
            G.edges[edge]['time'] = int(time)
            G.edges[sender, receiver]['sim'] = []

    Event_tokens = []
    with open(args.data_path_prefix + args.SE + args.data_path_suffix, 'r', encoding = 'utf-8') as file:
        for line in file:
            SE_tokens = ast.literal_eval(line)
            Event_tokens.append(SE_tokens)
	
    bene_list = []
    msg_list = []
    bene_gap_list = []
    inf_list = []
    node_num_list = []
    last_episode = 0
            
    for episode in range(episode_start, episode_end):
        if (episode-episode_start) % args.interval == 0:
            G, bene, msg, inf, msg_gap, node_num = diffusion(args, G, Event_tokens, episode, episode_start, last_episode)
            last_episode = episode
            bene_list.append(bene)
            inf_list.append(inf)
            msg_list.append(msg)
            bene_gap_list.append(msg_gap)
            node_num_list.append(node_num)

    print(sum(bene_list)/1000)
    print(sum(inf_list)/1000)
    print(sum(bene_list)/sum(msg_list))
    print(sum(bene_gap_list)/len(bene_gap_list))


if __name__ == "__main__":
	args = parse_args()
	main(args)
