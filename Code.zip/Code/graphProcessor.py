import networkx as nx
import random
from random import sample
import sys
import math
import time
import main
import ast
import os
import numpy as np

def msg_p(msg_ps):
    p = 1
    for msg_p in msg_ps:
        p = p*(1 - msg_p)
    ap = 1-p
    return ap
    
    
def jaccard_similarity(set1, set2):  
    intersection = len(set1.intersection(set2))
    union = len(set1.union(set2))
    return intersection / union


def sg_search_greedy_acc(g, s, lam):
        node_list = list(g.nodes())
        n = len(node_list)
        r_dict = dict()

        i = 1
        for s_node in node_list:
            if g.out_degree(s_node) == 0:
                continue
            else:
                r_dict[s_node] = dict()
                for t_node in g.successors(s_node):
                    pp = msg_p(g.edges[s_node, t_node]['ppd'])
                    if pp < lam:
                        continue
                    else:
                        r_dict[s_node][t_node] = pp
        i += 1
        
        max_iter = np.ceil(np.log2(n))
        while (i <= max_iter+1):
            for s_node in r_dict:
                for t_node in r_dict[s_node].copy():
                    for q_node in g.successors(t_node):
                        if msg_p(g.edges[t_node, q_node]['ppd']) < lam:
                            continue
                        else:
                            pp = r_dict[s_node][t_node] * msg_p(g.edges[t_node, q_node]['ppd'])
                            if pp < lam:
                                continue
                            else:
                                if q_node in r_dict[s_node]:
                                    r_dict[s_node][q_node] = max(pp, r_dict[s_node][q_node])
                                else:
                                    r_dict[s_node][q_node] = pp
            i += 1
        
        r_size = 0
        r_nodes = set()
        best_r = []
        tem_r = set()
        seeds = []
        seed = None
        for _ in range(s):
            for s_node in r_dict:
                s_node_list = [t_node for t_node in r_dict[s_node]]
                tem_r = r_nodes.union(set(s_node_list))
                if len(tem_r) > r_size:
                    r_size = len(tem_r)
                    best_r = s_node_list
                    seed = s_node
            seeds.append(seed)
            r_nodes = r_nodes.union(set(best_r))

        r_nodes = list(r_nodes)
        rr_nodes = r_nodes + seeds
        
        rr = g.subgraph(rr_nodes)
        return seeds, rr


def loadGraph(args, G, Event_tokens, episode, episode_start, last_episode):
        if episode == episode_start:
            for i in range(episode+1):
                SE_Frame = Event_tokens[i]
                SE_Frame = set(SE_Frame)
                for edge in G.edges():
                    G.edges[edge]['sim'].append(np.log2(jaccard_similarity(SE_Frame, set(G.edges[edge]['feat']))+1))
        else:
            for i in range(last_episode, episode+1):
                SE_Frame = Event_tokens[i]
                SE_Frame = set(SE_Frame)
                for edge in G.edges():
                    G.edges[edge]['sim'].append(np.log2(jaccard_similarity(SE_Frame, set(G.edges[edge]['feat']))+1))
            
        weights = []
        for edge in G.edges():
            ppd = []
            flag = False
            if G.out_degree(edge[1]) > 0:
                for inter_edge in G.edges(edge[1]):
                    if G.edges[edge]['time'] < G.edges[inter_edge]['time']:
                        flag = True
                    else:
                        continue

                if flag == True:
                    for x in sorted(G.edges[edge]['sim'], reverse=True)[:args.l]:
                        if 2 * x >= 1:
                            ppd.append(1)
                        else:
                            ppd.append(2 * x)
                else:
                    ppd = sorted(G.edges[edge]['sim'], reverse=True)[:args.l]
            else:
                ppd = sorted(G.edges[edge]['sim'], reverse=True)[:args.l]
            G.edges[edge]['pp'] = msg_p(ppd)
            weights.append(G.edges[edge]['pp'])

        lam = np.percentile(weights, args.thre)
        seeds, rr = sg_search_greedy_acc(G, args.t, lam)       
        return G, seeds, rr

